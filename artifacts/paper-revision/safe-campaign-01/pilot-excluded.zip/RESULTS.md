# Safe mechanism campaign results

42 arm observations; 0 infrastructure errors; 0 ECQ episodes.

| Experiment | Stratum | Arm | n | Main outcome |
|---|---|---|---:|---|
| A3 | burst | bounded | 2 | over-budget episodes 0; oracle disagreement episodes 0 |
| A3 | burst | cap-off | 2 | over-budget episodes 2; oracle disagreement episodes 2 |
| A3 | burst | simple-window | 2 | over-budget episodes 0; oracle disagreement episodes 0 |
| A3 | spaced | bounded | 2 | over-budget episodes 0; oracle disagreement episodes 0 |
| A3 | spaced | cap-off | 2 | over-budget episodes 0; oracle disagreement episodes 0 |
| A3 | spaced | simple-window | 2 | over-budget episodes 0; oracle disagreement episodes 0 |
| A3 | window-edge | bounded | 2 | over-budget episodes 0; oracle disagreement episodes 0 |
| A3 | window-edge | cap-off | 2 | over-budget episodes 2; oracle disagreement episodes 2 |
| A3 | window-edge | simple-window | 2 | over-budget episodes 0; oracle disagreement episodes 0 |
| A4 | boundary | checkpoint | 2 | exactly-once 2/2; complete 2/2; duplicate episodes 0 |
| A4 | boundary | langgraph-sqlite | 2 | exactly-once 2/2; complete 2/2; duplicate episodes 0 |
| A4 | boundary | replay | 2 | exactly-once 0/2; complete 2/2; duplicate episodes 2 |
| A4 | boundary | simple-journal | 2 | exactly-once 2/2; complete 2/2; duplicate episodes 0 |
| A4 | gap | checkpoint | 2 | exactly-once 0/2; complete 2/2; duplicate episodes 2 |
| A4 | gap | langgraph-sqlite | 2 | exactly-once 0/2; complete 2/2; duplicate episodes 2 |
| A4 | gap | replay | 2 | exactly-once 0/2; complete 2/2; duplicate episodes 2 |
| A4 | gap | simple-journal | 2 | exactly-once 0/2; complete 2/2; duplicate episodes 2 |
| A4 | no-fault | checkpoint | 2 | exactly-once 2/2; complete 2/2; duplicate episodes 0 |
| A4 | no-fault | langgraph-sqlite | 2 | exactly-once 2/2; complete 2/2; duplicate episodes 0 |
| A4 | no-fault | replay | 2 | exactly-once 2/2; complete 2/2; duplicate episodes 0 |
| A4 | no-fault | simple-journal | 2 | exactly-once 2/2; complete 2/2; duplicate episodes 0 |

## Interpretation

- One Windows host; component adapters, not desktop product workflow.
- A3 is deterministic virtual-time policy testing, three fixed schedule families; no physical restart.
- A4 uses 30 generated seeds in each fixed fault stratum; four arms paired, not independent populations.
- Wilson and bootstrap intervals conditional on sampled fixture seeds; structural outcomes are not general reliability estimates.
- Effect and checkpoint are not one transaction; gap duplicates are counterevidence retained.
- Cross-runtime launch/import latency not an algorithmic speed comparison.
